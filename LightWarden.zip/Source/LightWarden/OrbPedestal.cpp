// Fill out your copyright notice in the Description page of Project Settings.


#include "OrbPedestal.h"

AOrbPedestal::AOrbPedestal()
{

}

EOrbType AOrbPedestal::GetOrbType()
{
	return PedestalOrb;
}
